package com.ktis.moisdbbatch.step;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

import com.ktis.moisdbfilter.entity.MoisDbFilter;
import com.ktis.moisdbfilter.entity.enumeration.TrdStateGbn;
import com.ktis.moisdbfilter.entity.enumeration.Yn;
import com.ktis.moisdbfilter.service.MoisDbFilterService;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

@SpringBootTest(classes = {MoisDbFilterWriter.class})
class MoisDbFilterWriterTest {

  @Autowired
  private MoisDbFilterWriter moisDbFilterWriter;

  @MockBean
  private MoisDbFilterService moisDbFilterService;

  @Test
  public void 중복된_전화번호_DUPLICATION_Y_표기(){

    List<MoisDbFilter> moisDbFilterList = new ArrayList<>();

    MoisDbFilter moisDbFilter = MoisDbFilter.builder()
        .areaCode("02")
        .phNumber("733-6495")
        .telno("02-733-6495")
        .bizNo("영업중")
        .bizplcNm("볼 BOL")
        .dtlStateGbn("13")
        .dtlStateNm("")
        .trdStateGbn(TrdStateGbn.open)
        .localName("서울")
        .edsName("서울-종로-청운")
        .addrCode("")
        .arnoPostNo("")
        .arnoAdr("서울특별시 종로구 청운동 52-26번지 B1호")
        .roadCode("")
        .roadnPostNo("110030")
        .roadnAdr("서울특별시 종로구 자하문로33다길 4, B1호 (청운동)")
        .consCtgTypeNm("")
        .upjongCd("")
        .opnSvcNm("영화제작업")
        .baseDate("20191223")
        .x("197083.101529635")
        .y("453807.031821162")
        .creId("QA")
        .build();

    MoisDbFilter moisDbFilter1 = MoisDbFilter.builder()
        .areaCode("02")
        .phNumber("733-6495")
        .telno("02-733-6495")
        .bizNo("영업중1")
        .bizplcNm("볼 BO1L")
        .dtlStateGbn("131")
        .dtlStateNm("")
        .trdStateGbn(TrdStateGbn.open)
        .localName("서울1")
        .edsName("서울-종로-청운1")
        .addrCode("")
        .arnoPostNo("")
        .arnoAdr("서울특별시 종로구 청운동 52-26번지 B1호1")
        .roadCode("")
        .roadnPostNo("1100301")
        .roadnAdr("서울특별시 종로구 자하문로33다길 4, B1호 (청운동)1")
        .consCtgTypeNm("")
        .upjongCd("")
        .opnSvcNm("영화제작업")
        .baseDate("20191223")
        .x("197083.101529635")
        .y("453807.031821162")
        .creId("QA")
        .build();

    moisDbFilterList.add(moisDbFilter);
    moisDbFilterList.add(moisDbFilter1);

    moisDbFilterService.saveAll(moisDbFilterList);

    ArgumentCaptor<List<? extends MoisDbFilter>> argumentCaptor = ArgumentCaptor.forClass(List.class);

    verify(moisDbFilterService).saveAll(argumentCaptor.capture());

    moisDbFilterWriter.write(moisDbFilterList);

    assertEquals(Yn.N, argumentCaptor.getValue().get(0).getDuplicationYn());
    assertEquals(Yn.Y, argumentCaptor.getValue().get(1).getDuplicationYn());

  }

}